import logging, re
import apache_beam as beam
from apache_beam.io import WriteToText
from apache_beam.io.gcp.bigquery import ReadFromBigQuery, WriteToBigQuery

class FormatName(beam.DoFn):
  def process(self, element):
    # declare variables
    geoname = element['GEONAME']
    geoid = element['GEOID']
    tblid = element['TBLID']
    profln = element['PROFLN']
    estimate = element['ESTIMATE']
    mg_error = element['MG_ERROR']
    
    # split geoname if it's not null and not formatted properly
    if geoname != None and "--" in geoname:
        geoname_split = geoname.split('--')
        # first try clause executes code for cases with two '--'s
        # except clause as error handling; executes code for records with one "--"
        try:
            # strip trailing white space and reformat
            state = geoname_split[0].strip()
            territory = geoname_split[1].strip()
            territory_specification = geoname_split[2].strip()
            new_geoname = territory + ', ' + territory_specification + ', ' + state
        except IndexError:
            # strip trailing white space and reformat
            state = geoname_split[0].strip()
            territory = geoname_split[1].strip()
            new_geoname = territory + ', ' + state
    else:
        new_geoname = geoname
        
    # define final result of record
    record = {'TBLID': tblid, 'GEOID': geoid, 'GEONAME': new_geoname, 'PROFLN': profln, 'ESTIMATE': estimate, 'MG_ERROR':mg_error}
    return [record]
           
              
def run():
     PROJECT_ID = 'lucid-hook-288402'
     BUCKET = 'gs://lucid_dataflow_as/temp'

     options = {
     'project': PROJECT_ID
     }
     opts = beam.pipeline.PipelineOptions(flags=[], **options)

     p = beam.Pipeline('DirectRunner', options=opts)

     sql = 'SELECT TBLID, GEOID, GEONAME, PROFLN, ESTIMATE, MG_ERROR FROM US_Census_Bureau_refined.Peopleover65_USdeaths limit 300'
     bq_source = ReadFromBigQuery(query=sql, use_standard_sql=True, gcs_location=BUCKET)

     query_results = p | 'Read from BQ' >> beam.io.Read(bq_source)

     out_pcoll = query_results | 'Format Name' >> beam.ParDo(FormatName())

     out_pcoll | 'Log output' >> WriteToText('output.txt')

     dataset_id = 'US_Census_Bureau_refined'
     table_id = PROJECT_ID + ':' + dataset_id + '.' + 'PeopleOver65_beam'
     schema_id = 'TBLID:STRING,GEOID:STRING,GEONAME:STRING,PROFLN:INTEGER, ESTIMATE:FLOAT, MG_ERROR:STRING'

     out_pcoll | 'Write to BQ' >> WriteToBigQuery(table=table_id, schema=schema_id, custom_gcs_temp_location=BUCKET)
     
     result = p.run()
     result.wait_until_finish()      


if __name__ == '__main__':
  logging.getLogger().setLevel(logging.ERROR)
  run()